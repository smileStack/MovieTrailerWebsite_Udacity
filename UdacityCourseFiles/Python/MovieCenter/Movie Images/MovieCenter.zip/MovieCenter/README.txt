roject: Movie Trailer Website  - [Ashley Martinez]
================================

Required Libraries and Dependencies
-----------------------------------
[This program requires Python v2 to be installed. It will also require each of
the python files: fresh_tomatoes.py, media.py, and shows.py to be in the same local folder.


How to Run Project
------------------
To run, simply open your terminal, cd into the MovieCenter folder and type: python Entertainment_Center.py

Extra Credit Description
------------------------
Not sure if this was extra credit, but inheritance is used in the program.
